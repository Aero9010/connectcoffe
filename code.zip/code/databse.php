<?php

$host = "localhost";
$dbname = "id20603709_test1";
$username = "id20603709_test";
$password = "R8)|-|d/Pxg-)WXm";

$mysqli = new mysqli($host , $username,  $password,  $dbname);
                     
if ($mysqli->connect_errno) {
    die("Connection error: " . $mysqli->connect_error);
}

return $mysqli;