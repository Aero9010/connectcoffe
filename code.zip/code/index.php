<?php

session_start();

if (isset($_SESSION["user_id"])) {
    
    $mysqli = require __DIR__ . "/databse.php";
    
    $sql = "SELECT * FROM user
            WHERE id = {$_SESSION["user_id"]}";
            
    $result = $mysqli->query($sql);
    
    $user = $result->fetch_assoc();
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    
    
    <?php if (isset($user)): ?>
        <h1>Hello  <?= htmlspecialchars($user["name"]) ?></h1>
        

       
        <div class="container1">
    <p>
        <button onclick="readTag()" class="but1">SCAN NFC</button>
        <button class="but1" id="myButton">Redeem</button>
        <button class="but1"><a href="logout.php">Log out</a></button>
        
        
        
      </p>
      <pre id="log"></pre>
      <pre id="redeem"></pre>

      <div class="circles">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
        
      </div>
    </div>
      
    
    <?php else: ?>
        
        <div class="container">
  <header>
  <img src="BCC2.png" alt="logo" />

   
    <nav>
      <ul>
        <li><a href="about.html">About Us</a></li>
        
      </ul>
    </nav>
    
  </header>
  <main>
    <section class="hero">
      <h2 class="hero-title">Welcome to Connect Coffee</h2>
      <p class="hero-subtitle">We bring you the best coffee experience with our NFC-enabled Loyalty Scheme</p>
      <p class="but1"><a href="login.php">Log in</a> or <a href="signup.html">sign up</a></p>
      
    </section>

      <div class="feature">
        <img src="img1.png" alt="Coffee machine" class="feature-image">
        <h3 class="feature-title">Our Equipment</h3>
        <p class="feature-description">Here at Connect Coffee we strive to
             bring the best Loyalty Scheme possiable, through the use of our
              highly functional NFC Technology. We hope to bring you the best ever service you deserve each time you purchase a coffee through our Scheme.</p>

      </div>
    </section>
  </main>

</div>
        
        
        
        
        
        
    <?php endif; ?>
    <script src="nfc.js"></script>
</body>
</html>